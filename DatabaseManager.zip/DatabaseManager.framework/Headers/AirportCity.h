//
//  AirportCity.h
//  
//
//  Created by Indra Mohan on 26/11/15.
//
//

#import <CoreData/CoreData.h>

@interface AirportCity : NSManagedObject

@property (nonnull, nonatomic, retain) NSNumber *cityId;
@property (nonnull, nonatomic, retain) NSString *cityName;
@property (nonnull, nonatomic, retain) NSString *countryName;
@property (nonnull, nonatomic, retain) NSString *rawSynonyms;
@property (nullable, nonatomic, retain) NSString *code;
@property (nullable, nonatomic, retain) NSString *airportData;

@property (nonnull, nonatomic, retain) NSString *synonyms;

@property (nonnull, nonatomic, retain) NSNumber *isDomestic;
@property (nonnull, nonatomic, retain) NSNumber *isPopular;
@property (nonnull, nonatomic, retain) NSDate *lastUsed;

@property (nullable, nonatomic, retain) NSSet<AirportCity *> *childAirports;
@property (nullable, nonatomic, retain) NSSet<AirportCity *> *nearByAirports;
@property (nullable, nonatomic, retain) NSSet<AirportCity *> *nearByCities;
@property (nullable, nonatomic, retain) AirportCity *parentAirport;

@property (nullable, nonatomic, readonly) NSArray<AirportCity *> * nearByAirportArray;

- (nullable NSArray<AirportCity *> *)nearByAirportArray;
- (void)fillData:(nullable NSDictionary *)json;
- (void)updateSynonyms;

@end

NS_ASSUME_NONNULL_BEGIN

@interface AirportCity (CoreDataGeneratedAccessors)

- (void)addChildAirportsObject:(AirportCity *)value;
- (void)removeChildAirportsObject:(AirportCity *)value;
- (void)addChildAirports:(NSSet<AirportCity *> *)values;
- (void)removeChildAirports:(NSSet<AirportCity *> *)values;

- (void)addNearByAirportsObject:(AirportCity *)value;
- (void)removeNearByAirportsObject:(AirportCity *)value;
- (void)addNearByAirports:(NSSet<AirportCity *> *)values;
- (void)removeNearByAirports:(NSSet<AirportCity *> *)values;

- (void)addNearByCitiesObject:(AirportCity *)value;
- (void)removeNearByCitiesObject:(AirportCity *)value;
- (void)addNearByCities:(NSSet<AirportCity *> *)values;
- (void)removeNearByCities:(NSSet<AirportCity *> *)values;

@end

NS_ASSUME_NONNULL_END