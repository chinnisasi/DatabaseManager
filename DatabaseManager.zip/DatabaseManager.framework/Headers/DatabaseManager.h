//
//  DatabaseManager.h
//  DatabaseManager
//
//  Created by Sasidhar Koti on 29/01/21.
//  Copyright © 2021 MMT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AirportCity.h"

//! Project version number for DatabaseManager.
FOUNDATION_EXPORT double DatabaseManagerVersionNumber;

//! Project version string for DatabaseManager.
FOUNDATION_EXPORT const unsigned char DatabaseManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DatabaseManager/PublicHeader.h>


